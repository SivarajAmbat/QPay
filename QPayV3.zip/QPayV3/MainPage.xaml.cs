﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using QPayV3.Resources;
using ZXing;
using ZXing.Mobile;
using System.Diagnostics;
using Microsoft.Phone.Controls.Maps;
using Windows.Devices.Geolocation;
using System.Device.Location;
using System.Threading.Tasks;
using Windows.System;
using System.Threading;
using Microsoft.Phone.Maps.Controls;

namespace QPayV3
{
    public partial class MainPage : PhoneApplicationPage
    {
        //private MobileBarcodeScanner _scanner;

        // Constructor
        public MainPage()
        {
            InitializeComponent();
            //map1.Mode = new RoadMode();
            //map1.ZoomLevel = 7;



            this.Loaded += MainPage_Loaded;

            //_scanner = new MobileBarcodeScanner(this.Dispatcher);
            //_scanner.Dispatcher = this.Dispatcher;

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private async void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Getting your location ... ");

            try
            {
                //((ApplicationBarIconButton)sender).IsEnabled = false;
                GeoCoordinate coordinate = new GeoCoordinate(12.9724609851837, 77.5945204496384); 
                    // new GeoCoordinate(12.972506, 77.594833);

                    //await GetCurrentCoordinate();
                map1.Center = coordinate;
                map1.ZoomLevel = 15;
                map1.CartographicMode = MapCartographicMode.Road;
                Pushpin myPushpin = new Pushpin();
                myPushpin.Content = "JW Marriott";

                MapOverlay MyOverlay = new MapOverlay();
                MyOverlay.Content = myPushpin;
                MyOverlay.GeoCoordinate =  coordinate;
                MyOverlay.PositionOrigin = new Point(0, 0.5);
                Microsoft.Phone.Maps.Controls.MapLayer MyLayer = new Microsoft.Phone.Maps.Controls.MapLayer();

                MyLayer.Add(MyOverlay);

                map1.Layers.Add(MyLayer);
            }
            catch (Exception) // I meant to do that.    
            {
                MessageBoxResult result = MessageBox.Show("Location services is not enabled.  Would you like to go to the settings page to enable it?", "Error", MessageBoxButton.OKCancel);
                if (result == MessageBoxResult.OK)
                {
                   // await Launcher.LaunchUriAsync(new Uri("ms-settings-location:"));
                }
            }

            //Thread.Sleep(5000);

            MessageBox.Show("You are at JW Marriott. Continue?");
        }

        private async Task<GeoCoordinate> GetCurrentCoordinate()
        {
            Geolocator locator = new Geolocator();
            locator.DesiredAccuracy = PositionAccuracy.Default;

            Geoposition position = await locator.GetGeopositionAsync();

            GeoCoordinate coordinate = new GeoCoordinate(position.Coordinate.Latitude, position.Coordinate.Longitude);
            Debug.WriteLine(position.Coordinate.Latitude);
            Debug.WriteLine(position.Coordinate.Longitude);
            return coordinate;
        }

        

        private void btnContinue_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/DisplayCart.xaml", UriKind.RelativeOrAbsolute));
        }



        //private void HandleScanResult(Result result)
        //{
        //    string msg = "";
        //    if (result != null)
        //        msg = "Thanks! We have detected that you are at Reliance Supermarket, Forum Mall, Bangalore";
        //    else
        //        msg = "Scan Failed! Try again";

        //    this.Dispatcher.BeginInvoke(() => {
        //        MessageBox.Show(msg);
        //        Debug.WriteLine(msg);
        //        NavigationService.Navigate(new Uri("/DisplayCart.xaml", UriKind.RelativeOrAbsolute));
        //    });
        //}

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        _scanner.UseCustomOverlay = false;
        //        _scanner.TopText = "Hold camera up to Vendor's QR code displayed in the store";
        //        _scanner.BottomText = "Camera will automatically scan QR code\r\n\rPress the 'Back' button to cancel";

        //        _scanner.Scan().ContinueWith(t =>
        //        {
        //            if (t.Result != null)
        //            {
        //                Debug.WriteLine(t.Result);
        //                HandleScanResult(t.Result);
        //            }
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.WriteLine(ex.Message);
        //    }

        //}

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}