﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QPayV3
{
    public class CartItem : INotifyPropertyChanged
    {
        //public int ID { get; set; }
        //public string ItemName { get; set; }
        //public string ItemDescription { get; set; }
        //public int Quantity { get; set; }
        //public double UnitPrice { get; set; }
        //public double TotalPrice { get; set; }
        //public string ImagePath { get; set; }

        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; OnPropertyChanged("ID"); }
        }

        private string itemName;

        public string ItemName
        {
            get { return itemName; }
            set { itemName = value; OnPropertyChanged("ItemName"); }
        }

        private string itemDescription;

        public string ItemDescription
        {
            get { return itemDescription; }
            set { itemDescription = value;  OnPropertyChanged("ItemDescription"); }
        }

        private int quantity;

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; OnPropertyChanged("Quantity"); }
        }

        private double unitPrice;

        public double UnitPrice
        {
            get { return unitPrice; }
            set { unitPrice = value; OnPropertyChanged("UnitPrice"); }
        }

        private double totalPrice;

        public double TotalPrice
        {
            get { return totalPrice; }
            set { totalPrice = value; OnPropertyChanged("TotalPrice"); }
        }

        private string imagePath;

        public string ImagePath
        {
            get { return imagePath; }
            set { imagePath = value;  OnPropertyChanged("ImagePath"); }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));

        }
    }

    public class CartItemsDB
    {
        public ObservableCollection<CartItem> CartItems { get; set; }


        public CartItemsDB()
        {
            CartItems = new ObservableCollection<CartItem>();
            //LoadSampleData();
        }
        public void LoadSampleData()
        {
            CartItems.Add(new CartItem { ID = 1, ItemName = "Lifebuoy Total", ItemDescription = "125g  - ₹ 26", Quantity = 2, TotalPrice = 52, ImagePath="Assets/lifebuoy.png" });
            CartItems.Add(new CartItem { ID = 2, ItemName = "Bourbon Biscuits", ItemDescription = "60g  - ₹ 10", Quantity = 4, TotalPrice = 40, ImagePath = "Assets/bourbon.png" });
            CartItems.Add(new CartItem { ID = 3, ItemName = "Tiger Kreemz", ItemDescription = " 50g- ₹ 10", Quantity = 3, TotalPrice = 30, ImagePath = "Assets/TigerKreemz.png" });
            CartItems.Add(new CartItem { ID = 4, ItemName = "Cake Chocomuffils", ItemDescription = "35g  - ₹ 10", Quantity = 5, TotalPrice = 50, ImagePath = "Assets/muffils.png" });
        }
    }

    public class Cart : INotifyPropertyChanged
    {
        private int cartCount;

        public int CartCount
        {
            get { return cartCount; }
            set { cartCount = value; }
        }

        private double totalAmount;

        public double TotalAmount
        {
            get { return totalAmount; }
            set { totalAmount = value; }
        }

        public Cart()
        {
            cartCount = App.cartItemsDB.CartItems.Count();
            totalAmount = App.cartItemsDB.CartItems.Aggregate(0.00, (total, i) => total + (i.Quantity * i.UnitPrice));
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
