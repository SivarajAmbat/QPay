﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace QPayV3
{
    public partial class DisplayCart : PhoneApplicationPage
    {
        public DisplayCart()
        {
            InitializeComponent();
            this.Loaded += DisplayCart_Loaded;
        }

        private void DisplayCart_Loaded(object sender, RoutedEventArgs e)
        {
            cartItemsList.ItemsSource = App.cartItemsDB.CartItems;
            CartInfo.DataContext = new Cart();
        }

        private void ApplicationBarIconButton_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/NewItemScan.xaml", UriKind.RelativeOrAbsolute));
        }

        private void ApplicationBarIconButton_Click_1(object sender, EventArgs e)
        {
            App.cartItemsDB.CartItems.Clear();
        }

        private void ApplicationBarIconButton_Click_2(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/PaymentPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}