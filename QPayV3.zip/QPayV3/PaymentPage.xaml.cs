﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace QPayV3
{
    public partial class PaymentPage : PhoneApplicationPage
    {
        public PaymentPage()
        {
            InitializeComponent();
            this.Loaded += PaymentPage_Loaded;
        }

        private void PaymentPage_Loaded(object sender, RoutedEventArgs e)
        {
            //paymentTypes.ItemsSource = new List<string> { "Pay By Cash", "Credit Card", "Debit Card", "Netbanking", "PayTM", "Paypal" };
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Work in progress");
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/BillPrinting.xaml", UriKind.Relative));
        }
    }
}