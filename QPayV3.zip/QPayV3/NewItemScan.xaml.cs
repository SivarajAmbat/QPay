﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using ZXing.Mobile;
using ZXing;
using System.Diagnostics;

namespace QPayV3
{
    public partial class NewItemScan : PhoneApplicationPage
    {
        private MobileBarcodeScanner _scanner;
        private CartItem newCartItem;

        public NewItemScan()
        {
            InitializeComponent();
            _scanner = new MobileBarcodeScanner(this.Dispatcher);
            _scanner.Dispatcher = this.Dispatcher;
        }

        private void HandleScanResult(Result result)
        {
            string msg = "";
            if (result != null)
                msg = String.Format("Scanned {0} successfully!", result.Text);
            else
                msg = "Scan Failed! Try again";

            this.Dispatcher.BeginInvoke(() =>
            {
                Debug.WriteLine(msg);
                newCartItem = new CartItem();
                ScannedItemDetails.DataContext = newCartItem;
                EditArea.DataContext = newCartItem;
                EditArea.Visibility = Visibility.Visible;
                switch (result.Text)
                {
                    case "8901030585821":
                        Debug.WriteLine("Lifebouy Total");
                        newCartItem.ItemName = "Lifebouy Total";
                        newCartItem.ItemDescription = "125g  - ₹ 26";
                        newCartItem.Quantity = 1;
                        newCartItem.UnitPrice = 26;
                        newCartItem.ImagePath = "Assets/lifebuoy.png";
                        break;
                    case "8901063339071":
                        Debug.WriteLine("Muffils");
                        newCartItem.ItemName = "Cake Chocomuffils";
                        newCartItem.ItemDescription = "35g  - ₹ 10";
                        newCartItem.Quantity = 1;
                        newCartItem.UnitPrice = 10;
                        newCartItem.ImagePath = "Assets/muffils.png";
                        break;
                    case "8901063164031":
                        Debug.WriteLine("TigerKreemz");
                        newCartItem.ItemName = "Tiger Kreemz";
                        newCartItem.ItemDescription = "50g- ₹ 10";
                        newCartItem.Quantity = 1;
                        newCartItem.UnitPrice = 10;
                        newCartItem.ImagePath = "Assets/TigerKreemz.png";
                        break;
                    case "8901063139190":
                        Debug.WriteLine("Bourbon");
                        newCartItem.ItemName = "Bourbon Biscuits";
                        newCartItem.ItemDescription = "60g  - ₹ 10";
                        newCartItem.Quantity = 1;
                        newCartItem.UnitPrice = 10;
                        newCartItem.ImagePath = "Assets/bourbon.png";
                        break;
                    //case "90162602":
                    //    Debug.WriteLine("Redbull");
                    //    newCartItem.ItemName = "Redbull";
                    //    newCartItem.ItemDescription = "250ml  - ₹ 110";
                    //    newCartItem.Quantity = 1;
                    //    newCartItem.UnitPrice = 110;
                    //    newCartItem.ImagePath = "Assets/redbull.png";
                    //    break;
                    //case "8906017290026":
                    //    Debug.WriteLine("Bisleri");
                    //    newCartItem.ItemName = "Lifebouy Total";
                    //    newCartItem.ItemDescription = "125g  - ₹ 26";
                    //    newCartItem.Quantity = 1;
                    //    newCartItem.UnitPrice = 26;
                    //    newCartItem.ImagePath = "Assets/lifebuoy.png";
                    //    break;
                }
                newCartItem.TotalPrice = newCartItem.Quantity * newCartItem.UnitPrice;
                App.cartItemsDB.CartItems.Add(newCartItem);


                // NavigationService.Navigate(new Uri("/DisplayCart.xaml", UriKind.RelativeOrAbsolute));
            });
        }

        /*
         CartItems.Add(new CartItem { ID = 1, ItemName = "Lifebuoy Total", ItemDescription = "125g  - ₹ 26", Quantity = 2, TotalPrice = 52, ImagePath="Assets/lifebuoy.png" });
         CartItems.Add(new CartItem { ID = 2, ItemName = "Bourbon Biscuits", ItemDescription = "60g  - ₹ 10", Quantity = 4, TotalPrice = 40, ImagePath = "Assets/bourbon.png" });
         CartItems.Add(new CartItem { ID = 3, ItemName = "Tiger Kreemz", ItemDescription = " 50g- ₹ 10", Quantity = 3, TotalPrice = 30, ImagePath = "Assets/TigerKreemz.png" });
         CartItems.Add(new CartItem { ID = 4, ItemName = "Cake Chocomuffils", ItemDescription = "35g  - ₹ 10", Quantity = 5, TotalPrice = 50, ImagePath = "Assets/muffils.png" });
    */

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _scanner.UseCustomOverlay = false;
                _scanner.TopText = "Scan the product barcode using the mobile camera";
                _scanner.BottomText = "Camera will automatically scan the barcode\r\n\rPress the 'Back' button to cancel";

                _scanner.Scan().ContinueWith(t =>
                {
                    if (t.Result != null)
                    {
                        Debug.WriteLine(t.Result);
                        HandleScanResult(t.Result);
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            --newCartItem.Quantity;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ++newCartItem.Quantity;
        }

        private void ApplicationBarIconButton_Click(object sender, EventArgs e)
        {
            NavigationService.Navigate(new Uri("/DisplayCart.xaml", UriKind.RelativeOrAbsolute));
        }

        private void ApplicationBarIconButton_Click_1(object sender, EventArgs e)
        {
            newCartItem = new CartItem();
        }
    }
}